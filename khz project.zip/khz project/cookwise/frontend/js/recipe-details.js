document.addEventListener('DOMContentLoaded', () => {
    const urlParams = new URLSearchParams(window.location.search);
    const id = urlParams.get('id');
    
    if (id) {
        fetchRecipe(id);
    } else {
        document.getElementById('recipe-container').innerHTML = '<div class="empty-state"><h3>Recipe Not Found</h3><p>No ID provided.</p></div>';
    }
});

let currentMeal = null;
let baseServings = 2;
let currentServings = 2;
let cookingSteps = [];
let currentStepIndex = 0;

// Timer state
let timerInterval = null;
let timerSeconds = 0;

function getRecipeIngredients(meal) {
    const ingredients = [];
    for (let i = 1; i <= 20; i++) {
        const ingredient = meal[`strIngredient${i}`];
        const measure = meal[`strMeasure${i}`];
        if (ingredient && ingredient.trim()) {
            ingredients.push({
                name: ingredient.trim(),
                measure: measure ? measure.trim() : ""
            });
        }
    }
    return ingredients;
}

async function fetchRecipe(id) {
    try {
        const res = await fetch(`${MEALDB_BASE_URL}/lookup.php?i=${id}`);
        if (res.ok) {
            const data = await res.json();
            if (data.meals && data.meals.length > 0) {
                currentMeal = data.meals[0];
                currentMeal.kcal = getStableKcal(currentMeal);
                renderRecipe();
                return;
            }
        }
        document.getElementById('recipe-container').innerHTML = '<div class="empty-state"><h3>Recipe Not Found</h3></div>';
    } catch (err) {
        console.error(err);
        document.getElementById('recipe-container').innerHTML = '<div class="empty-state"><h3>Network Error</h3></div>';
    }
}

function renderRecipe() {
    const container = document.getElementById('recipe-container');
    const ingredients = getRecipeIngredients(currentMeal);
    
    // Parse instructions into steps
    cookingSteps = currentMeal.strInstructions
        .split(/\r?\n/)
        .filter(step => step.trim().length > 10); // basic filter for actual steps

    if (cookingSteps.length === 0) {
        cookingSteps = [currentMeal.strInstructions];
    }

    const html = `
        <div class="details-hero mt-4">
            <img src="${currentMeal.strMealThumb}" alt="${currentMeal.strMeal}">
            <div class="details-hero-overlay">
                <div class="details-meta-tags">
                    <span class="badge">🇨🇳 ${currentMeal.strArea || 'Unknown'}</span>
                    <span class="badge">🍽️ ${currentMeal.strCategory || 'Unknown'}</span>
                </div>
                <h1>${currentMeal.strMeal}</h1>
            </div>
        </div>

        <div class="action-bar">
            <button class="btn btn-primary" onclick="startCookingMode()">🍳 Start Cooking</button>
            <button class="btn btn-outline" data-id="${currentMeal.idMeal}" data-name="${currentMeal.strMeal}" data-thumb="${currentMeal.strMealThumb}" onclick="saveRecipe(this)">❤️ Save Recipe</button>
            <button class="btn btn-outline" onclick="printRecipe()">🖨 Print Recipe</button>
        </div>

        <div class="layout-grid">
            <div class="main-content">
                <div class="panel">
                    <h3>Instructions</h3>
                    <div class="instructions">
                        ${cookingSteps.map((step, i) => `<p><strong>Step ${i + 1}:</strong> ${step}</p>`).join('')}
                    </div>
                </div>
            </div>
            
            <div class="sidebar">
                <div class="panel">
                    <h3>Ingredients</h3>
                    <div class="servings-control">
                        <button class="servings-btn" onclick="updateServings(-1)">-</button>
                        <span class="servings-num" id="servings-display">${currentServings}</span>
                        <button class="servings-btn" onclick="updateServings(1)">+</button>
                        <span style="font-size:14px; color:var(--clr-text-muted); margin-left: 8px;">Servings</span>
                    </div>
                    <ul class="ingredients-list" id="ingredients-list-render">
                        ${renderIngredientsList(ingredients)}
                    </ul>
                </div>
                
                <div class="panel">
                    <h3>Estimated Nutrition</h3>
                    <p style="color: var(--clr-text-muted); font-size: 14px; margin-bottom: 16px;">
                        Based on standard ingredient measurements.
                    </p>
                    <ul class="ingredients-list">
                        <li>
                            <span>🔥 Calories</span> 
                            <span>${currentMeal.kcal} kcal</span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    `;

    container.innerHTML = html;
}

function parseMeasure(measureStr) {
    // Basic parser to pull out numbers to multiply
    const match = measureStr.match(/^([\d.,\s\/-]+)(.*)$/);
    if (!match) return { num: null, rest: measureStr };
    
    let numPart = match[1].trim();
    // naive conversion for mixed fractions like "1 1/2" -> 1.5
    // for university project scope, simple float works
    let value = parseFloat(numPart);
    if (isNaN(value)) return { num: null, rest: measureStr };
    
    return { num: value, rest: match[2] };
}

function renderIngredientsList(ingredients) {
    return ingredients.map(ing => {
        let displayMeasure = ing.measure;
        
        // Very basic scaling logic
        const parsed = parseMeasure(ing.measure);
        if (parsed.num !== null) {
            const scaled = (parsed.num / baseServings) * currentServings;
            // Round to 1 decimal
            displayMeasure = `${Math.round(scaled * 10) / 10} ${parsed.rest}`;
        }
        
        return `<li><span>${ing.name}</span> <strong>${displayMeasure}</strong></li>`;
    }).join('');
}

window.updateServings = function(delta) {
    const newS = currentServings + delta;
    if (newS >= 1 && newS <= 12) {
        currentServings = newS;
        document.getElementById('servings-display').innerText = currentServings;
        const ingredients = getRecipeIngredients(currentMeal);
        document.getElementById('ingredients-list-render').innerHTML = renderIngredientsList(ingredients);
    }
}

// Cooking Mode Logic
window.startCookingMode = function() {
    currentStepIndex = 0;
    updateCookingUI();
    document.getElementById('cooking-mode').style.display = 'flex';
    // Request notification permission for timer
    if (Notification.permission !== "granted" && Notification.permission !== "denied") {
        Notification.requestPermission();
    }
}

document.getElementById('btn-exit-cooking').addEventListener('click', () => {
    document.getElementById('cooking-mode').style.display = 'none';
    resetTimer();
});

document.getElementById('btn-cook-prev').addEventListener('click', () => {
    if (currentStepIndex > 0) {
        currentStepIndex--;
        updateCookingUI();
    }
});

document.getElementById('btn-cook-next').addEventListener('click', () => {
    if (currentStepIndex < cookingSteps.length - 1) {
        currentStepIndex++;
        updateCookingUI();
    }
});

document.getElementById('btn-cook-finish').addEventListener('click', () => {
    finishCooking();
});

function updateCookingUI() {
    const isLastStep = currentStepIndex === cookingSteps.length - 1;

    document.getElementById('cooking-step-counter').innerText = `STEP ${currentStepIndex + 1} OF ${cookingSteps.length}`;
    document.getElementById('cooking-instruction-text').innerText = cookingSteps[currentStepIndex];

    // Prev button: disable on first step
    document.getElementById('btn-cook-prev').disabled = currentStepIndex === 0;

    // Swap Next ↔ Finish based on whether this is the last step
    const nextBtn   = document.getElementById('btn-cook-next');
    const finishBtn = document.getElementById('btn-cook-finish');

    if (isLastStep) {
        nextBtn.style.display   = 'none';
        finishBtn.style.display = 'inline-flex';
    } else {
        nextBtn.style.display   = 'inline-flex';
        finishBtn.style.display = 'none';
    }
}

function finishCooking() {
    // Stop the timer cleanly if it is running
    resetTimer();

    // Close Cooking Mode
    document.getElementById('cooking-mode').style.display = 'none';

    // Scroll the main page back to the top so the user sees the recipe
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

// Timer Logic
function formatTimer(sec) {
    const m = Math.floor(sec / 60).toString().padStart(2, '0');
    const s = (sec % 60).toString().padStart(2, '0');
    return `${m}:${s}`;
}

function updateTimerDisplay() {
    document.getElementById('cooking-timer').innerText = formatTimer(timerSeconds);
}

document.getElementById('btn-timer-start').addEventListener('click', () => {
    timerSeconds += 60;
    updateTimerDisplay();
});

document.getElementById('btn-timer-reset').addEventListener('click', () => {
    resetTimer();
});

document.getElementById('btn-timer-toggle').addEventListener('click', () => {
    const btn = document.getElementById('btn-timer-toggle');
    if (timerInterval) {
        clearInterval(timerInterval);
        timerInterval = null;
        btn.innerText = 'Resume Timer';
    } else {
        if (timerSeconds <= 0) return;
        btn.innerText = 'Pause Timer';
        timerInterval = setInterval(() => {
            timerSeconds--;
            updateTimerDisplay();
            if (timerSeconds <= 0) {
                clearInterval(timerInterval);
                timerInterval = null;
                btn.innerText = 'Start Timer';
                alert('Time is up!');
                if (Notification.permission === "granted") {
                    new Notification("CookWise Timer", { body: "Your cooking timer has finished!" });
                }
            }
        }, 1000);
    }
});

function resetTimer() {
    clearInterval(timerInterval);
    timerInterval = null;
    timerSeconds = 0;
    updateTimerDisplay();
    document.getElementById('btn-timer-toggle').innerText = 'Start Timer';
}

window.printRecipe = function() {
    window.print();
}
